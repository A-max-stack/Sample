<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<form action="ie">
<input type="number" name="id" placeholder="Enter the id"><br>
<input type="text" name="name" placeholder="Enter the name"><br>
<input type="email" name="email" placeholder="Enter the email"><br>
<input type="password" name="pwd" placeholder="Enter the password"><br>
<button>Submit</button>
</form>

</body>
</html>