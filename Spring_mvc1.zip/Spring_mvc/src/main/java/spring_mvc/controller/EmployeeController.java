package spring_mvc.controller;



import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import spring_mvc.entity.Student;

@Controller
public class EmployeeController {

    @RequestMapping("/ie")
    @ResponseBody
    public String insertData(@ModelAttribute Student student) {

        return student.getId() + " "
                + student.getName() + " "
                + student.getEmail() + " "
                + student.getPwd();
    }
}