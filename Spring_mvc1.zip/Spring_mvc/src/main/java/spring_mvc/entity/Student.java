package spring_mvc.entity;

import lombok.Data;

@Data
public class Student {

    private int id;
    private String name;
    private String email;
    @Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", email=" + email + ", pwd=" + pwd + "]";
	}
	private String pwd;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
    
}